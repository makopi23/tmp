package com.example.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.domain.Book;
import com.example.repository.BookRepository;

@RestController
@RequestMapping("resource")
public class BookController {
    @Autowired
    BookRepository bookRepository;

    // Book全件取得
    @RequestMapping(method = RequestMethod.GET)
    List<Book> getBooks(){
        System.out.println("★Book全件取得");
        List<Book> books = bookRepository.findAll();
//        for(Book book: books){
//            System.out.println(book.getTitle());
//        }
        return books;
    }

    // Book１件取得
    @RequestMapping(value = "{isbn}", method = RequestMethod.GET)
    Book getBook(@PathVariable String isbn){
        System.out.println("★Book１件取得");
        List<Book> books = bookRepository.findAll();
        for(Book book: books){
            if(isbn.equals(book.getIsbn())){
                return book;
            }
        }
        return new Book();
    }

    // Book１件作成
    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    Book createBook(@RequestBody Book book){
        System.out.println("★Book１件作成");
        return bookRepository.save(book);
    }

//    // Book１件作成
//    @RequestMapping(method = RequestMethod.POST)
//    Book createBook(@RequestBody Map<String, String> map){
//        System.out.println("★Book１件作成");
//        Book book = new Book();
//        return bookRepository.save(book);
//    }

//    // Book１件作成
//    @RequestMapping(method = RequestMethod.OPTIONS)
//    Book testOptions(@RequestBody Map<String, String> map){
//        System.out.println("★testOptions");
//        Book book = new Book();
//        return bookRepository.save(book);
//    }

    // Book１件更新
    @RequestMapping(value = "{isbn}", method = RequestMethod.PUT)
    Book updateBook(@PathVariable String isbn, @RequestBody Book book){
        System.out.println("★Book１件更新");
        book.setIsbn(isbn);
        return bookRepository.save(book);
    }

    // Book１件削除
    @RequestMapping(value = "{isbn}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void deleteBook(@PathVariable String isbn){
        System.out.println("★Book１件削除");
        List<Book> books = bookRepository.findAll();
        for(Book book: books){
            if(isbn.equals(book.getIsbn())){
                bookRepository.delete(book);
                break;
            }
        }
    }
}
