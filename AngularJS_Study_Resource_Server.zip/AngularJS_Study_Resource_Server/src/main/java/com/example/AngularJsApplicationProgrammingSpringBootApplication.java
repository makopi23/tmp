package com.example;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.repository.BookRepository;

@SpringBootApplication
@RestController
@EnableAutoConfiguration
@ComponentScan
public class AngularJsApplicationProgrammingSpringBootApplication {
    @Autowired
    BookRepository bookRepository;

    @RequestMapping("/")
    String home(){
        return "Hello world!";
    }

    /*
    @RequestMapping(value = "/chap05/http", method = RequestMethod.GET, produces = "text/html")
    String http(@RequestParam("name") String name){
        System.out.println("★/chap05/http");
        System.out.println("name: " + name);
        return name;
    }

    @RequestMapping(value = "/chap05/http2", method = RequestMethod.GET, produces = "text/html")
    String http2(@RequestParam("name") String name){
        System.out.println("★/chap05/http2");
        System.out.println("name: " + name);

        if("".equals(name)){
            return "こんにちは、名無しの権兵衛さん！";
        }else{
            return "こんにちは、" + name + "さん！";
        }

    }

    @RequestMapping(value = "/chap05/http3", method = RequestMethod.POST, produces = "text/html")
    String http3(@RequestBody Map<String, String> map){
        System.out.println("★/chap05/http3");
        System.out.println("map.get(\"name\"): " + map.get("name"));

        if("".equals(map.get("name"))){
            return "こんにちは、名無しの権兵衛さん！";
        }else{
            return "こんにちは、" + map.get("name") + "さん！";
        }
    }

    @RequestMapping(value = "/chap05/http4", method = RequestMethod.POST, produces = "text/html")
    String http4(@RequestParam("name") String name){
        System.out.println("★/chap05/http4");
        System.out.println("name: " + name);

        if("".equals(name)){
            return "こんにちは、名無しの権兵衛さん！";
        }else{
            return "こんにちは、" + name + "さん！";
        }
    }
    */



	public static void main(String[] args) {
		SpringApplication.run(AngularJsApplicationProgrammingSpringBootApplication.class, args);
	}
}
