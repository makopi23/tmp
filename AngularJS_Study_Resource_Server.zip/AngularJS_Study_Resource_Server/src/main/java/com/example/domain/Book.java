package com.example.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "books")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {
    @Id
    private String isbn;        // ISBNコード
    @Column
    private String title;       // 書名
    @Column
    private String price;       // 価格
    @Column
    private String publish;     // 出版社
    @Column
    private String published;   // 刊行日
}
