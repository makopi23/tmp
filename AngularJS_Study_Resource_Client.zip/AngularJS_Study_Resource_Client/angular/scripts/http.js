angular.module('myApp', [])
	.controller('MyController', ['$scope','$http', function($scope, $http) {

		// 書籍を全件取得
		function getAllBooks(){
			$http({
				method: 'GET',
				url: 'http://localhost:8080/resource'
			}).success(function(data, status, headers, config){
				$scope.books = data;
				console.log(data);
			}).error(function(data, status, headers, config){
				$scope.result = '!!通信に失敗しました!!';
			});
		}

		// 初期状態で、すべての書籍情報を取得
		getAllBooks();

		// [登録]ボタンクリックで、入力された書籍情報を新規登録
		$scope.oninsert = function(){
			console.log("[登録]ボタンクリック");
			console.log($scope.book);

			$http({
				method: 'POST',
				url: 'http://localhost:8080/resource',
				data: $scope.book
			}).success(function(data, status, headers, config){
				getAllBooks();
			}).error(function(data, status, headers, config){
				$scope.result = '!!通信に失敗しました!!';
			});
		};

		// [編集]ボタンクリックで、該当する書籍情報をフォームに反映
		$scope.onedit = function(isbn){
			console.log("[編集]ボタンクリック");

			$http({
				method: 'GET',
				url: 'http://localhost:8080/resource/' + isbn,
			}).success(function(data, status, headers, config){
				$scope.book = data;
				console.log(data);
			}).error(function(data, status, headers, config){
				$scope.result = '!!通信に失敗しました!!';
			});
		};

		// [更新]ボタンクリックで、入力された書籍情報で保存データを更新
		$scope.onupdate = function(){
			console.log("[更新]ボタンクリック");

			$http({
				method: 'PUT',
				url: 'http://localhost:8080/resource/' + $scope.book.isbn,
				data: $scope.book
			}).success(function(data, status, headers, config){
				getAllBooks();
			}).error(function(data, status, headers, config){
				$scope.result = '!!通信に失敗しました!!';
			});
		};

		// リスト上の[削除]ボタンクリックで、該当する書籍情報を破棄
		$scope.ondelete = function(isbn){
			console.log("[削除]ボタンクリック");

			$http({
				method: 'DELETE',
				url: 'http://localhost:8080/resource/' + isbn,
			}).success(function(data, status, headers, config){
				getAllBooks();
			}).error(function(data, status, headers, config){
				$scope.result = '!!通信に失敗しました!!';
			});
		};


	}]);
