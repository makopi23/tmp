angular.module('myApp', [ 'ngResource' ])
	.controller('MyController', ['$scope', '$resource', function($scope, $resource) {
		// サーバサイドアクセスのためのresourceオブジェクトを取得
		var Book = $resource(
			'http://localhost:8080/resource/:isbn',
			{ isbn: '@isbn' },
			{ update: { method: 'PUT' }}
		);

		// 初期状態で、すべての書籍情報を取得
		$scope.books = Book.query();

		// [登録]ボタンクリックで、入力された書籍情報を新規登録
		$scope.oninsert = function(){
			console.log("[登録]ボタンクリック");
			console.log($scope.book);

			Book.save(
				$scope.book,
				function(){
					$scope.books = Book.query();
				}
			);
		};

		// [編集]ボタンクリックで、該当する書籍情報をフォームに反映
		$scope.onedit = function(isbn){
			console.log("[編集]ボタンクリック");
			$scope.book = Book.get({ isbn: isbn });
		};

		// [更新]ボタンクリックで、入力された書籍情報で保存データを更新
		$scope.onupdate = function(){
			console.log("[更新]ボタンクリック");

			Book.update(
				$scope.book,
				function(){
					$scope.books = Book.query();
				}
			);
		};

		// リスト上の[削除]ボタンクリックで、該当する書籍情報を破棄
		$scope.ondelete = function(isbn){
			console.log("[削除]ボタンクリック");
			Book.delete(
				{ isbn: isbn },
				function(){
					$scope.books = Book.query();
					console.log($scope.books);
				}
			);
		};
	}]);
